package com.project.bloodBank.bean;

public interface DonorInfoBean {
	
	Long getId();
	
//	
//	String getFirst_name();
//
//	String getLast_name();
//
//	String getEmai();
//
//	String getPassword();
//
//	Date getDate_of_birth();
//
//	String getGender();
//
//	String getAddress();
//
//	Long getContact_number();
//
//	Long getAlternate_contact_number();
//
//	String getType();
//
//	Long getBlood_group_id();
//	
//	Long getBlood_bank_id();


}
