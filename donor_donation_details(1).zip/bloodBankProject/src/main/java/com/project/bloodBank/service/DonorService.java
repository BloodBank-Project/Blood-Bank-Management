package com.project.bloodBank.service;

public interface DonorService {

}
