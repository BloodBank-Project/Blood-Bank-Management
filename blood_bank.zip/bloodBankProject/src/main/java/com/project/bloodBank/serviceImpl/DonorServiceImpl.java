package com.project.bloodBank.serviceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.bloodBank.bean.DonorBean;
import com.project.bloodBank.entity.DonorEntity;
import com.project.bloodBank.exceptions.DonorNotFoundException;
import com.project.bloodBank.repository.DonorRepository;
import com.project.bloodBank.service.DonorService;

@Service
public class DonorServiceImpl implements DonorService {
	@Autowired
	private DonorRepository donorRepository;


	@Override
	public void save(DonorBean donorBean) {

		DonorEntity donorEntity = new DonorEntity();
		entityToBean(donorEntity, donorBean);
		donorRepository.save(donorEntity);
	}

	@Override
	public DonorBean getByDonorId(Long id) {
		DonorBean donorBean = new DonorBean();
//		DonorEntity donorEntity;
		try {
			DonorEntity donorEntity = donorRepository.findById(id).
						orElseThrow(() -> new DonorNotFoundException("donor is not found to delete with this " + id));
			entityToBean(donorEntity, donorBean);
		} catch (DonorNotFoundException e) {
			throw e;
		}
		return donorBean;
	}
	
	@Override
	public void update(DonorBean donorBean) {
		Optional<DonorEntity> donorEntity = donorRepository.findById(donorBean.getId());
		if (donorEntity.isPresent()) {
			DonorEntity donorEntity2 = donorEntity.get();
			donorEntity2.setId(donorBean.getId());
			donorEntity2.setName(donorBean.getName());
			donorRepository.save(donorEntity2);
		} else {
			try {
				throw new DonorNotFoundException("Donor is not available to update with this " + donorBean.getId());
			} catch (DonorNotFoundException e) {
				throw e;
			}
		}
	}
	
	@Override
	public void delete(Long id) {
//		donorRepository.deleteById(id);

		Optional<DonorEntity> findById = donorRepository.findById(id);
		if (findById.isEmpty()) {
			try {
				findById.orElseThrow(() -> new DonorNotFoundException("donar id is  not found to delete"));
			} catch (DonorNotFoundException e) {
				throw e;
			}
		} else {
			donorRepository.deleteById(id);
		}
	}
	
	@Override
	public List<DonorBean> getAllDonors() {
		List<DonorEntity> entities = new ArrayList<>();
		List<DonorBean> beans = new ArrayList<>();
		entityToBeanList(entities, beans);
		return beans;
	}
	
	public void entityToBean(DonorEntity donorEntity, DonorBean donorBean) {
		donorBean.setId(donorEntity.getId());
		donorBean.setName(donorEntity.getName());
	}

	public void entityToBeanList(List<DonorEntity> donorEntity, List<DonorBean> donorBean) {

		for (DonorEntity donorEntity2 : donorEntity) {

			DonorBean bean = new DonorBean();
			bean.setId(donorEntity2.getId());
			bean.setName(donorEntity2.getName());
			donorBean.add(bean);
		}
	}

	
//	----------------------------using Entity----------------------------------------
//	@Override
//	public DonorEntity save(DonorEntity donorEntity) {
//		 return donorRepository.save(donorEntity);
//	}
//
//	@Override
////	public Optional<DonorEntity> getById(Long id) {
//	public DonorEntity getById(Long id) {
//
////		return donorRepository.findById(id);
//
//		Optional<DonorEntity> findById = donorRepository.findById(id);
//		if (findById.isEmpty()) {
//			try {
//				findById.orElseThrow(() -> new DonorNotFoundException(id + "donar id is not found to get"));
//			} catch (DonorNotFoundException e) {
//				throw e;
//			}
//		}
//		return findById.get();
//	}
//
//	@Override
//	public Optional<DonorEntity> update(DonorEntity donorEntity) {
//		Optional<DonorEntity> findById = donorRepository.findById(donorEntity.getId());
//		if (findById.isPresent()) {
//			donorRepository.save(donorEntity);
//			return findById;
//		}
////		else {
////			System.out.println("Enter the correct id");
////		}
////		return null;
//		return Optional.of(findById.orElseThrow(() -> new DonorNotFoundException("donar id is not found to update")));
//
//	}
//
//	@Override
//	public List<DonorEntity> getAll() {
//		return donorRepository.findAll();
//	}
//	
//	@Override
//	public void delete(Long id) {
////		donorRepository.deleteById(id);
//
//		Optional<DonorEntity> findById = donorRepository.findById(id);
//		if (findById.isEmpty()) {
//			try {
//				findById.orElseThrow(() -> new DonorNotFoundException("donar id is  not found to delete"));
//			} catch (DonorNotFoundException e) {
//				throw e;
//			}
//		} else {
//			donorRepository.deleteById(id);
//		}
//	}
//	
}
