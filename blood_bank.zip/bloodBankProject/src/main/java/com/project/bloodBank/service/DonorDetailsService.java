package com.project.bloodBank.service;

import java.util.List;
import java.util.Optional;

import com.project.bloodBank.bean.DonorBean;
import com.project.bloodBank.bean.DonorDetailsBean;
import com.project.bloodBank.entity.DonorDetailsEntity;

public interface DonorDetailsService {

	void save(DonorDetailsBean donorBean);

	DonorDetailsBean getByDonorId(Long id);

	List<DonorDetailsBean> getAllDonors();

	void update(DonorDetailsBean donorBean);

	void delete(Long id);

//
////	DonorDetailsEntity save(DonorDetailsEntity donorEntity);
//	void save(DonorDetailsBean detailsBean);
//
////	Optional<DonorDetailsEntity> getById(Long id);
//	
//	DonorDetailsEntity getById(Long id);
//	
//	Optional<DonorDetailsEntity> update(DonorDetailsEntity donorEntity);
//	
//	void delete(Long id);
//	
//	List<DonorDetailsEntity> getAll();

}
