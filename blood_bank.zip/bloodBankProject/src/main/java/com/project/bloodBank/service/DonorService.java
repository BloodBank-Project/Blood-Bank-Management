package com.project.bloodBank.service;

import java.util.List;
import java.util.Optional;

import com.project.bloodBank.bean.DonorBean;
import com.project.bloodBank.entity.DonorEntity;

public interface DonorService {
	
	void save(DonorBean donorBean);
	
	DonorBean getByDonorId(Long id);
	
	List<DonorBean> getAllDonors();
	
	void update(DonorBean donorBean);

	void delete(Long id);
	
//	---------------------using Entity------------------------
	
////	DonorEntity save(DonorEntity donorEntity);
//
////	Optional<DonorEntity> getById(Long id);
//	DonorEntity getById(Long id);
//	
//	Optional<DonorEntity> update(DonorEntity donorEntity);
//	
//	void delete(Long id);
//	
//	List<DonorEntity> getAll();
}
