package com.project.bloodBank.bean;

import java.sql.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Data
public class DonorDetailsBean {
	
	private Long donationId;
	
	private Long bloodQuantity;
	
	private Date dateOfDonation;
	
	private String status;
	
}
